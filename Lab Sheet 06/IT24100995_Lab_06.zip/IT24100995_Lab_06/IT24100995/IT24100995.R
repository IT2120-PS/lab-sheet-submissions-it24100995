#Q1

#(i)
#binomial
#(ii)
X <-1-pbinom(46,50,0.85,lower.tail = TRUE)
X
Y <-pbinom(46,50,0.85,lower.tail = TRUE)
Y

#Q2
#(i)
# X= Number of calls received in 1 hour
#(ii)
#poisson
#(iii)
S<-1-ppois(12,15,lower.tail=TRUE)
S
E<- ppois(12,15,lower.tail=FALSE)
E
